<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $guarded = [];

    public function invoice_payment()
    {
        return $this->hasOne(InvoicePayment::class, 'invoice_id', 'my_invoice_id');
    }

    public function invoice_pending_payment()
    {
        return $this->hasOne(InvoicePendingPayment::class, 'invoice_id', 'my_invoice_id');
    }
}
