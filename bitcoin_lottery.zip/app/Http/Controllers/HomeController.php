<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

use App\User;
use App\Lottery;
use App\Setting;
use App\Transaction;
use App\Ticket;
use App\Invoice;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'verified']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = Auth::user();
        $role = $user->role->type;
        if ($role == 'admin') {
            return redirect()->route('admin.home');
        }else if($role == 'user'){
            $payment_flag = session('payment_flag');
            if($payment_flag) {
                return redirect(route('payment'));
            }
            session(['page' => 'home']);
            $user = Auth::user();
            return view('home', compact('user'));
        }
    }

    public function change_password(Request $request)
    {
        $cur_password = $request['old_password'];
        $new_password = $request['new_password'];
        if(!Hash::check($cur_password, Auth::user()->password)){
            $errors = ['error' => 'The old password is incorrect.'];
            return $errors;
        }else{
            DB::table('users')
                ->where('id', Auth::user()->id)
                ->update([
                    'password' => Hash::make($new_password),
            ]);
            return [
                'success' => 'The password was changed successfully.'
            ];
        }
    }

    public function change_profile(Request $request)
    {
        $user = Auth::user();
        if($request->get('username') != ''){
            $user->username = $request->get('username');
        }
        
        if($request->get('email') != ''){
            $user->email = $request->get('email');
        }
        if($request->hasfile('photo')){
            $fileName = time() . '.' . request()->photo->getClientOriginalExtension();
            request()->photo->move(public_path('img/avatar'),$fileName);
            $user->photo = 'img/avatar/' . $fileName;
        }
        $user->update();
        return [
            'success' => 'success'
        ];
    }

    public function payment(Request $request) {
        $payment_flag = session('payment_flag');
        $data = session('post_home');
        if ($payment_flag) {
            $invoice_id = $data['invoice_id'];
            $invoice = Invoice::where('my_invoice_id', $invoice_id)->first();
            $secret = $invoice->secret;
            $amount = $invoice->price_in_bitcoin;
            $callback_url = config('app.call_back_root') . "callback?invoice_id=" . $invoice_id . "&secret=" . $secret;

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => config('app.block_receive_root') . "v2/receive?key=" . config('app.bitcoin_api_key') . "&callback=" . urlencode($callback_url) . "&xpub=" . config('app.xpub'),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                    "Accept: */*",
                    "Accept-Encoding: gzip, deflate",
                    "Cache-Control: no-cache",
                    "Connection: keep-alive",
                    "Host: api.blockchain.info",
                    "cache-control: no-cache"
                ),
            ));

            $response = curl_exec($curl);
            $response = json_decode($response);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                return $err;
            }

            dd($response->message);
            
            // $invoice = Invoice::where('my_invoice_id', $invoice_id);
            $invoice->update([
                'address' => $response->address,
                'user_id' => Auth::id(),
            ]);
            return view('payment', compact('response', 'amount'));
        }
    }

    

    public function create_ticket(Request $request) {
        $amount = $request->get('amount');
        $reference_no = $request->get('reference_no');
        $lottery = Lottery::orderBy('created_at', 'desc')->first();

        $payment_data = session('post_home');
        session()->forget('post_home');
        $wallet_address = $payment_data['wallet_address'];
        $transaction = Transaction::create([
            'amount' => $amount,
            'lottery_id' => $lottery->id,
            'wallet_address' => $wallet_address,
            'reference_no' => $request->reference_no,
        ]);

        

    }

}
