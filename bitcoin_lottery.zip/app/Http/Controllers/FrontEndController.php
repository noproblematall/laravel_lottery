<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Invoice;
use App\Setting;
use App\InvoicePayment;
use App\InvoicePendingPayment;

use Auth;

class FrontEndController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('welcome');
    }    
    
    public function post_home(Request $request) 
    {
        $request->validate([
            'email' => 'required|email',
            'wallet_address' => 'required',
            'bit_number' => 'required'
        ]);

        $data = $request->all();
        $email = $data['email'];

        $amount = $data['bit_number'] * Setting::first()->cost_of_ticket;
        $wallet_address = $data['wallet_address'];
        $invoice_id = uniqid();
        $secret = md5(uniqid());
        $invoice = Invoice::create([
            'secret' => $secret,
            'my_invoice_id' => $invoice_id,
            'price_in_bitcoin' => $amount,
        ]);

        $data['invoice_id'] = $invoice_id;
        $request->session()->put('payment_flag', 1);
        $request->session()->put('post_home', $data);
        
        $auth_user = Auth::user();
        if($auth_user) {
            return redirect(route('payment'));
        } else {
            $user = User::whereEmail($email)->first();
            if($user) {
                return redirect(route('login'));
            } else {
                return redirect(route('register'));
            }
        }
    }

    public function callback(Request $request)
    {
        $data = $request->all();
        $invoice_id = $data['invoice_id'];
        $transaction_hash = $data['transaction_hash'];
        $address = $data['address'];
        $confirmations = $data['confirmations'];
        $secret = $data['secret'];
        $value_in_btc = $data['value'] / 100000000;
        $invoice = Invoice::where('my_invoice_id', $invoice_id)->first();
        if ($invoice->address != $address) {
            echo 'Incorrect Receiving Address';
            return;
        }
        if ($invoice->secret != $secret) {
            echo 'Invalid Secret';
            return;
        }
        if ($confirmations >= 4) {
            InvoicePayment::create([
                'transaction_hash' => $transaction_hash,
                'value' => $value_in_btc,
                'invoice_id' => $invoice_id,
            ]);
            
            $pending_payment = InvoicePendingPayment::where('invoice_id', $invoice_id);
            if ($pending_payment->exists()) {
                $pending_payment->delete();
            }

            echo "*ok*";
        }else{
            InvoicePendingPayment::create([
                'transaction_hash' => $transaction_hash,
                'value' => $value_in_btc,
                'invoice_id' => $invoice_id,
            ]);
            echo "Waiting for confirmations";
        }
    }

    public function payment_verify(Request $request)
    {
        $invoice_id = $request->get('invoice_id');
        $invoice_payment = InvoicePayment::where('invoice_id', $invoice_id);
        $invoice_pending = InvoicePendingPayment::where('invoice_id', $invoice_id);
        if ($invoice_payment->exists()) {
            return response()->json([
                'status' => 1
            ]);
        }else if ($invoice_pending->exists()) {
            return response()->json([
                'status' => 0
            ]);
        }else{
            return response()->json([
                'status' => 2
            ]);
        }
    }
}
