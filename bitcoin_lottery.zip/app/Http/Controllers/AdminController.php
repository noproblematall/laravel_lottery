<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Lottery;
use App\Ticket;
use App\Transaction;
use App\Setting;

class AdminController extends Controller
{
    private $pagesize;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->pagesize = 10;
        $this->middleware(['auth', 'admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        session(['page' => 'home']);
        return view('admin.index');
    }

    public function user_manage(Request $request)
    {
        session(['page' => 'user_manage']);
        if ($request->has('pagesize')) {
            $this->pagesize = $request->get('pagesize');
            if($this->pagesize == 'all'){
                $this->pagesize = User::where('role_id', '2')->count();
            }
        }
        $pagesize = $this->pagesize;
        $user = User::where('role_id', '2')->orderBy('created_at', 'desc')->paginate($pagesize);
        return view('admin.user_manage', compact('user', 'pagesize'));
    }

    public function user_delete($id)
    {
        if (User::where('id', $id)->exists()) {
            User::find($id)->delete();
            return back()->withSuccess('Deleted Successfully.');
        } else {
            return back()->withErrors(['exist'=>'The User is not exist.']);
        }
        
    }

    public function setting()
    {
        session(['page' => 'setting']);
        if (!Setting::first()) {
            $setting = null;
            return view('admin.setting', compact('setting'));
        } else {
            $setting = Setting::first();
            return view('admin.setting', compact('setting'));
        }
        
    }

    public function time_cost(Request $request)
    {
        $request->validate([
            'time_of_prize1' => 'required',
            'time_of_prize2' => 'required',
            'time_of_prize3' => 'required',
            'cost_of_ticket' => 'required',
        ]);

        if (!Setting::first()) {
            Setting::create($request->all());
            return back()->withSuccess('Created successfully.');
        } else {
            Setting::first()->update($request->all());            
            return back()->withSuccess('Updated successfully.');
        }

    }
    
}
