<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Register | <?php echo e(config('app.name', 'Lottery')); ?></title>

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/spinkit.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bracket.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
  </head>

  <body>
    <?php
        $payment_flag = session('payment_flag');
        $data = session('post_home');
        $email = '';
        if($payment_flag) {$email = $data['email'];}
    ?>
    <div class="d-flex align-items-center justify-content-center bg-custom ht-100v">        
        <form action="<?php echo e(route('register')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base" id="register_form">
                <div class="signin-logo tx-center tx-28 tx-bold tx-inverse"><a href="<?php echo e(asset('/')); ?>"><span class="tx-normal">[ LOGO ]</span></a></div>
                <div class="tx-center mg-b-30">Please enter your info</div>

                <div class="form-group">
                <div class="form-group">
                    <input type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" placeholder="Enter Your User ID" required>
                    <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div><!-- form-group -->
                <div class="form-group">
                    <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($email == '' ? old('email') : $email); ?>" placeholder="Enter your email" required>
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div><!-- form-group -->
                <div class="form-group">
                    <label class="d-block tx-11 tx-uppercase tx-medium tx-spacing-1">The password must be at least 8 characters.</label>
                    <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" placeholder="Enter your password" required>
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div><!-- form-group -->
                <div class="form-group">
                    <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm your password" required>
                </div><!-- form-group -->

                <div class="form-group tx-12">By clicking the Sign Up button below, you agreed to our privacy policy and terms of use of our website.</div>
                <button type="submit" class="btn btn-custom btn-block">Sign Up</button>

                <div class="mg-t-10 tx-center">Already a member? <a href="<?php echo e(route('login')); ?>" class="tx-info">Sign In</a></div>
                <div class="mg-t-10 tx-center"><a href="<?php echo e(route('welcome')); ?>" class="tx-info">Go to homepage</a></div>
            </div><!-- login-wrapper -->
        </form>
    </div><!-- d-flex -->

    <div class="loader_container display_none">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1 bg-gray-800"></div>
            <div class="sk-child sk-bounce2 bg-gray-800"></div>
            <div class="sk-child sk-bounce3 bg-gray-800"></div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script defer>
        
    </script>
  </body>
</html>
<?php /**PATH D:\xampp\htdocs\projects\bitcoin_lottery\resources\views/auth/register.blade.php ENDPATH**/ ?>