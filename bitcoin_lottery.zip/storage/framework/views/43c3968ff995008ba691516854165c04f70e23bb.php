<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('library/datetime/css/bootstrap-datetimepicker.min.css')); ?>">
<style>
    body{background-color: #E9ECEF;}
    .btn-custom{background-color: #FDB702;border-color: #FDB702;color: #24126A;font-weight: bold;}
    .invalid-feedback {display: block;}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $page_range = array('10', '25', '50', '100');
?>
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="br-mainpanel">
        <div class="br-pagetitle">
            <i class="icon ion-document-text"></i>
            <div>
            <h4>Edit Lottery</h4>
            <p class="mg-b-0">Please edit the lottery</p>
        </div>            
    </div><!-- d-flex -->
    <?php if(Session::has('success')): ?>
        <input type="hidden" name="" id="success_message" value="<?php echo e(Session::get('success')); ?>">
    <?php else: ?>
        <input type="hidden" name="" id="success_message" value="">
    <?php endif; ?>
    <?php if(Session::has('errors')): ?>
        <input type="hidden" name="" id="error_message" value="<?php echo e(session('errors')->first('exist')); ?>">
    <?php else: ?>
        <input type="hidden" name="" id="error_message" value="">
    <?php endif; ?>
    <div class="br-pagebody" id="app">            
        <div class="row row-sm mg-t-20 card card-body">
            <div class="col-md-6">
                <form action="<?php echo e(route('admin.lottery_update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value=" <?php echo e($lottery->id); ?> ">
                    <div class="form-group">
                        <label for="lottery_date">Date</label>
                        <input type="text" name="date" class="form-control" value="<?php echo e($lottery->date); ?>" id="lottery_date">
                        <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="prize1_time">Time for prize1</label>
                        <input type="text" name="time_of_prize1" class="form-control" value=" <?php echo e($lottery->time_of_prize1); ?> " id="prize1_time">
                        <?php if ($errors->has('time_of_prize1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('time_of_prize1'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="prize2_time">Time for prize2</label>
                        <input type="text" name="time_of_prize2" class="form-control" value=" <?php echo e($lottery->time_of_prize2); ?> " id="prize2_time">
                        <?php if ($errors->has('time_of_prize2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('time_of_prize2'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="prize3_time">Time for prize3</label>
                        <input type="text" name="time_of_prize3" value=" <?php echo e($lottery->time_of_prize3); ?> " class="form-control" id="prize3_time">
                    </div>
                    <?php if ($errors->has('time_of_prize3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('time_of_prize3'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <div class="form-group">
                        <label for="prize3_time">Cost of ticket</label>
                        <input type="text" name="cost_of_ticket" value=" <?php echo e($lottery->cost_of_ticket); ?> " class="form-control" id="cost_of_ticket">
                        <?php if ($errors->has('cost_of_ticket')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cost_of_ticket'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <button type="submit" class="btn btn-custom form-control">Update Lottery</button>
                </form>
            </div>
           
        </div><!-- row -->
    </div><!-- br-pagebody -->
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('library/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/datetime/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('#lottery_date').datetimepicker({
                useCurrent: false,
                minDate: new Date(),
                format: 'Y-M-D'
            });
            $('#prize1_time').datetimepicker({
                useCurrent: false,
                format: 'HH:mm',
            })
            $("#prize1_time").on("dp.change", function (e) {
                $('#prize2_time').data("DateTimePicker").minDate(e.date);
                $('#prize3_time').data("DateTimePicker").minDate(e.date);
            });
            $('#prize2_time').datetimepicker({
                useCurrent: false,
                format: 'HH:mm',
            })
            $("#prize2_time").on("dp.change", function (e) {
                $('#prize3_time').data("DateTimePicker").minDate(e.date);
            });
            $('#prize3_time').datetimepicker({
                useCurrent: false,
                format: 'HH:mm',
            })
            
            if($('#success_message').val() != ''){
                toast_call('Success', $('#success_message').val())
            }else if($('#error_message').val() != ''){
                toast_call('Error', $('#error_message').val(), 'error')
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\bitcoin_lottery\resources\views/admin/lottery_edit.blade.php ENDPATH**/ ?>