<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Login</title>

    <!-- vendor css -->
    <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/ionicons.min.css')); ?>" rel="stylesheet">

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bracket.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
  </head>

  <body>

    <div class="d-flex align-items-center justify-content-center bg-custom ht-100v" id="app">
        
        <div class="login-wrapper wd-500 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base text-center" style="padding-top:20px;" v-if="ready_flag">
            <div class="signin-logo tx-center tx-28 tx-bold tx-inverse" style="margin-bottom:15px;"><a href="<?php echo e(route('welcome')); ?>">LOGO</a></div>
            <div class="tx-center mg-b-10">Please send <b><?php echo e($amount); ?></b> BTC to </div>
            <p><b><?php echo e($response->address); ?></b></p>
            <img src="<?php echo e(config('app.block_chain_root')); ?>qr?data=<?php echo e($response->address); ?>&size=125" alt="" srcset="">
        </div><!-- login-wrapper -->

        <div class="login-wrapper wd-500 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base text-center" style="padding-top:20px;" v-if="waiting_flag">
            <div class="signin-logo tx-center tx-28 tx-bold tx-inverse" style="margin-bottom:15px;"><a href="<?php echo e(route('welcome')); ?>">LOGO</a></div>
            <div class="tx-center mg-b-10">Please send <b><?php echo e($amount); ?></b> BTC to </div>
            <p><b><?php echo e($response->address); ?></b></p>
            <img src="<?php echo e(config('app.block_chain_root')); ?>qr?data=<?php echo e($response->address); ?>&size=125" alt="" srcset="">
        </div><!-- login-wrapper -->

        <div class="login-wrapper wd-500 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base text-center" style="padding-top:20px;" v-if="paid_flag">
            <div class="signin-logo tx-center tx-28 tx-bold tx-inverse" style="margin-bottom:15px;"><a href="<?php echo e(route('welcome')); ?>">LOGO</a></div>
            <div class="tx-center mg-b-10">Please send <b><?php echo e($amount); ?></b> BTC to </div>
            <p><b><?php echo e($response->address); ?></b></p>
            <img src="<?php echo e(config('app.block_chain_root')); ?>qr?data=<?php echo e($response->address); ?>&size=125" alt="" srcset="">
        </div><!-- login-wrapper -->

    </div><!-- d-flex -->

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        var vm = new Vue({
            el: "#app",
            data: {
                ready_flag: true,
                waiting_flag: false,
                paid_flag: false,
            },
            created: function(){
                let check = setInterval(function(){
                    axios.get('/payment_verify')
                        .then(response => {
                            console.log(response);
                        })
                        .catch(error => {
                            console.log(error);
                        });
                }, 5000);
            }
        })
    </script>
  </body>
</html>


<?php /**PATH D:\xampp\htdocs\projects\bitcoin_lottery\resources\views/payment.blade.php ENDPATH**/ ?>