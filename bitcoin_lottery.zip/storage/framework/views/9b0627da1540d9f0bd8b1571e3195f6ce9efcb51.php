<?php $__env->startSection('content'); ?>
<?php
    $page_range = array('10', '25', '50', '100');
?>
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="br-mainpanel">
        <div class="br-pagetitle">
            <i class="icon fa fa-trophy" style="font-size:60px;"></i>
            <div>
            <h4>Lottery Management</h4>
            <p class="mg-b-0">Registed All Lotteries</p>
        </div>            
    </div><!-- d-flex -->
    <?php if(Session::has('success')): ?>
        <input type="hidden" name="" id="success_message" value="<?php echo e(Session::get('success')); ?>">
    <?php else: ?>
        <input type="hidden" name="" id="success_message" value="">
    <?php endif; ?>
    <?php if(Session::has('errors')): ?>
        <input type="hidden" name="" id="error_message" value="<?php echo e(session('errors')->first('exist')); ?>">
    <?php else: ?>
        <input type="hidden" name="" id="error_message" value="">
    <?php endif; ?>
    <div class="br-pagebody" id="app">            
        <div class="row row-sm mg-t-20 card card-body">
            <div class="col-md-12">
                <div class="search-form">
                    <form action="<?php echo e(route('admin.lottery_manage')); ?>" method="POST" class="form-inline float-left" id="searchForm">
                        <?php echo csrf_field(); ?>
                        <label for="pagesize" class="control-label ml-3 mb-2">Show :</label>
                        <select class="form-control form-control-sm mx-2 mb-2" name="pagesize" id="pagesize">
                            <option value="10" <?php if($pagesize == '10'): ?> selected <?php endif; ?>>10</option>
                            <option value="25" <?php if($pagesize == '25'): ?> selected <?php endif; ?>>25</option>
                            <option value="50" <?php if($pagesize == '50'): ?> selected <?php endif; ?>>50</option>
                            <option value="100" <?php if($pagesize == '100'): ?> selected <?php endif; ?>>100</option>
                            <option value="all" <?php if(!in_array($pagesize, $page_range)): ?> selected <?php endif; ?>>All</option>
                        </select>
                    </form>
                    
                    <div class="clearfix"></div>
                </div>
                <div class="bd bd-gray-300 rounded table-responsive">
                    <table class="table table-bordered mg-b-0">
                        <thead>
                            <th>No</th>
                            <th>Date</th>
                            <th>Time for prize 1</th>
                            <th>Time for prize 2</th>
                            <th>Time for prize 3</th>
                            <th>Cost Of Ticket</th>
                            <th>Is End</th>
                            <th>Action</th>
                        </thead>
                        <tbody>                           
                            <?php $__empty_1 = true; $__currentLoopData = $lottery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e((($lottery->currentPage() - 1 ) * $lottery->perPage() ) + $loop->iteration); ?></td>
                                    <td><?php echo e($item->date); ?></td>
                                    <td><?php echo e($item->time_of_prize1); ?></td>
                                    <td><?php echo e($item->time_of_prize2); ?></td>
                                    <td><?php echo e($item->time_of_prize3); ?></td>
                                    <td><?php echo e($item->cost_of_ticket); ?></td>
                                    <td>
                                        <?php if($item->is_end): ?>
                                            Yes
                                        <?php else: ?>
                                            Not Yet
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.lottery_edit', $item->id)); ?>">&nbsp;<i class="fa fa-edit" style="color:#24126A;">&nbsp;</i></a>
                                        <a href="<?php echo e(route('admin.lottery_delete', $item->id)); ?>" onclick="return confirm('Are you sure?');">&nbsp;<i class="fa fa-trash" style="color:#24126A;">&nbsp;</i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4">There is not registed lotteries.</td>
                                </tr>

                            <?php endif; ?>                        
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-12">
                <div class="clearfix mt-2">
                    <div class="float-left" style="margin: 0;">
                        <p>Total <strong style="color: red"><?php echo e($lottery->total()); ?></strong> entries</p>
                    </div>
                    <div class="float-right" style="margin: 0;">
                        <?php echo e($lottery->appends(['pagesize' => $pagesize])->links()); ?>

                    </div>
                </div>
            </div>
        </div><!-- row -->
    </div><!-- br-pagebody -->
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $("#pagesize").change(function(){
                $("#searchForm").submit();
            });
            
            if($('#success_message').val() != ''){
                toast_call('Success', $('#success_message').val())
            }else if($('#error_message').val() != ''){
                toast_call('Error', $('#error_message').val(), 'error')
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\bitcoin_lottery\resources\views/admin/lottery.blade.php ENDPATH**/ ?>