<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Lottery Start</title>
</head>
<body>
    <table style="text-align: center;">
        <tr><td><h2>Hi, <?php echo e($name); ?></h2></td></tr>
        <tr><td><h4>Now, We have started new lottery for <?php echo e($prize); ?></h4></td></tr>
    </table>
</body>
</html><?php /**PATH D:\xampp\htdocs\projects\bitcoin_lottery\resources\views/emails/lottery_start.blade.php ENDPATH**/ ?>