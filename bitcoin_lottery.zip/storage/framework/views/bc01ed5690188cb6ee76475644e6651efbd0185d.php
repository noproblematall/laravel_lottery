<?php
  $page = session('page');  
?>
  <div class="br-logo">
    <a href="<?php echo e(route('welcome')); ?>">
      
      LOGO
    </a>
  </div>

  <div class="br-sideleft sideleft-scrollbar">
    <label class="sidebar-label pd-x-10 mg-t-20 op-3 text-center"><?php echo e($user->role->type); ?></label>
    <ul class="br-sideleft-menu">

      <li class="br-menu-item">
        <a href="<?php echo e(route('admin.home')); ?>" class="br-menu-link <?php echo e($page==='home' ? 'active' : null); ?>">
          <i class="menu-item-icon icon ion-ios-home-outline tx-24"></i>
          <span class="menu-item-label">Dashboard</span>
        </a>
      </li>      

    </ul>
    <br>
  </div><?php /**PATH D:\xampp\htdocs\projects\bitcoin_lottery\resources\views/layouts/side.blade.php ENDPATH**/ ?>