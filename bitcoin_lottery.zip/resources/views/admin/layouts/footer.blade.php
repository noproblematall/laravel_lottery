<footer class="br-footer" style="margin-top:50px;">
    <div class="footer-left">
    <div class="mg-b-2">Food. All Rights Reserved.</div>
    </div>
</footer>